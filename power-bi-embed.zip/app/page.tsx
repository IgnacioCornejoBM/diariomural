export default function PowerBIDashboard() {
  return (
    <div className="flex flex-col items-center min-h-screen bg-[#f4f4f4]">
      <h1 className="mt-5 text-2xl font-bold text-[#333]">Diario Mural Digital</h1>
      <iframe
        title="Diario mural digital"
        width="1140"
        height="541.25"
        src="https://app.powerbi.com/reportEmbed?reportId=e07034b1-54b4-4eb2-9160-439b13314f68&autoAuth=true&ctid=5644a6c4-883a-4d2f-8258-78fa0c6d717d"
        className="m-5 max-w-full border-none"
        allowFullScreen={true}
      />
    </div>
  )
}
